#!/bin/sh
while [ 1 ]
do
	/usr/bin/python /monitor/monitor/agent.py 2> /dev/null 
done
